package com.example.agenda

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.agenda.databinding.ActivityCadastrarusuarioBinding
import com.example.agenda.databinding.ActivityMainBinding

class cadastrarusuario : AppCompatActivity() {

    private lateinit var binding: ActivityCadastrarusuarioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCadastrarusuarioBinding.inflate(layoutInflater)


        setContentView(binding.root)

        binding.btCadastrarUsuario.setOnClickListener{

            val nome = binding.editName.text.toString()
            val sobrenome = binding.editSobrenome.text.toString()
            val idade = binding.editIdade.text.toString()
            val telefone = binding.editTelefone.text.toString()

            if(nome.isEmpty() || sobrenome.isEmpty() || idade.isEmpty() || telefone.isEmpty()){
                Toast.makeText(this, "PREENCHA TODOS OS CAMPOS", Toast.LENGTH_SHORT).show()
            }

        }

    }
}