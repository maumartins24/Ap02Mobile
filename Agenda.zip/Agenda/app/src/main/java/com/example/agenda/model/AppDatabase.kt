package com.example.agenda.model

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.agenda.dao.UsuarioDao
import com.example.agenda.model.Usuario

@Database(entities = [Usuario::class], version = 1 )
abstract class AppDatabase : RoomDatabase(){

    abstract fun usuarioDao() : UsuarioDao
    companion object{
        //definindo banco
        private const val DATABASE_NAME: String = "DB_USUARIO"

        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this){
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    DATABASE_NAME
                ).build()
                INSTANCE= instance
                instance
            }

        }

    }



}